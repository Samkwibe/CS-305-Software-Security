package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

// CS-305 Project Two | Samuel Raymond Kwibe | April 10, 2026
// Added ChecksumController to handle the /hash endpoint
// SHA-256 is used for the checksum - no new dependencies needed since
// MessageDigest is already part of the Java SE standard library

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

@RestController
class ChecksumController {

	@GetMapping("/hash")
	public String getChecksum() {

		// data string includes my name as required by the assignment
		String data = "Samuel Raymond Kwibe : CS305-Project2 : ArtemisFinancial-2026";
		String pageOutput;

		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			byte[] rawBytes = md.digest(data.getBytes("UTF-8"));

			// convert raw bytes to hex string
			StringBuilder hexBuilder = new StringBuilder();
			for (int i = 0; i < rawBytes.length; i++) {
				String hexChunk = Integer.toHexString(0xff & rawBytes[i]);
				if (hexChunk.length() == 1) {
					hexBuilder.append("0");
				}
				hexBuilder.append(hexChunk);
			}

			String checksumHex = hexBuilder.toString();

			pageOutput = "<html>"
					+ "<head><title>CS-305 Hash Verification</title></head>"
					+ "<body style='font-family:Arial,sans-serif;padding:30px;max-width:700px'>"
					+ "<h2>Artemis Financial &mdash; Checksum Verification</h2><hr/>"
					+ "<p><strong>Developer:</strong> Samuel Raymond Kwibe</p>"
					+ "<p><strong>Data:</strong> " + data + "</p>"
					+ "<p><strong>Algorithm:</strong> SHA-256</p>"
					+ "<p><strong>Checksum:</strong></p>"
					+ "<p style='background:#f0f0f0;padding:12px;word-break:break-all;font-family:monospace'>"
					+ checksumHex + "</p>"
					+ "</body></html>";

		} catch (NoSuchAlgorithmException | java.io.UnsupportedEncodingException ex) {
			pageOutput = "Error generating hash: " + ex.getMessage();
		}

		return pageOutput;
	}
}